# -*- coding: utf-8 -*-
import datetime
import pandas
from xhtml2pdf import pisa
from utils import ENT_FED, WORDS, to_upper, remove_article, remove_precisions,remove_names, search_vowel, search_consonant
import logging
import warnings
import os
import unicodedata

def resource_path(relative_path):
        """ Get absolute path to resource, works for dev and for PyInstaller """
        try:
            # PyInstaller creates a temp folder and stores path in _MEIPASS
            global base_path
            base_path = sys._MEIPASS
        except Exception:
            base_path = os.path.abspath(".")
    
        return os.path.join(base_path, relative_path)


warnings.filterwarnings("ignore")
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')

def setup_logger(name, log_file, level=logging.INFO):
    """Function setup as many loggers as you want"""

    handler = logging.FileHandler(log_file)        
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger

class BaseGenerator(object):
    """class Base"""
    def generate(self):
        raise NotImplementedError('No implement.')

    def parse(self, complete_name, last_name, mother_last_name=None, city=None,
        state_code=None):
        if city is not None:
            self.city = to_upper(city)
        if state_code is not None:
            self.state_code = to_upper(state_code)
        if mother_last_name is not None:
            self.mother_last_name = to_upper(mother_last_name)
            self.mother_last_name = remove_article(self.mother_last_name)
            self.mother_last_name = remove_precisions(self.mother_last_name)
        self.complete_name = to_upper(complete_name)
        self.complete_name = remove_names(self.complete_name)
        self.complete_name = remove_precisions(self.complete_name)
        self.last_name = to_upper(last_name)
        self.last_name = remove_article(self.last_name)
        self.last_name = remove_precisions(self.last_name)
        
    def data_fiscal(self, complete_name, last_name, mother_last_name, birth_date):
        initials = self.initials_name(complete_name, last_name, mother_last_name)
        completename = self.verify_words(initials)
        birth_date = self.parse_date(birth_date)
        return '%s%s' % (completename, birth_date)
        
    def initials_name(self, complete_name, last_name, mother_last_name):
        ini_last_name = last_name[0:1] # Initial last name
        last_name_vowel = search_vowel(last_name) # Find the first vowel of the last name
        if mother_last_name is None:
            ini_mothlast_name = 'X'
        else:
            ini_mothlast_name = mother_last_name[0:1] # Initial mother's last name
        ini_compl_name = complete_name[0:1] # Initial complete name
        initials = '%s%s%s%s' % (ini_last_name, last_name_vowel, 
                                 ini_mothlast_name, ini_compl_name)
        return initials

    def verify_words(self, rfc):
        for item in WORDS:
            if item == rfc:
                rfc = 'XXXX'
                break
        return rfc

    def parse_date(self, fecha):
        try:
            fecha_type = type(fecha)
            if fecha is None:
                fecha = datetime.datetime.today()
            else:
                if not (fecha_type is datetime.datetime or fecha_type is datetime.date or pandas.Timestamp):
                    fecha = datetime.datetime.strptime(fecha, '%d-%m-%Y').date()
       
            year = str(fecha.year)
            year = year[2:4]
            month = str(fecha.month).zfill(2) # Fill with zeros to the left.
            day = str(fecha.day).zfill(2)
            birth_date = '%s%s%s' % (year, month, day) 
            return birth_date
        except Exception as exc:
            raise exc

    def city_search(self, name_city):
        data = ''    
        for key, value in ENT_FED.items():
            if key == name_city:
                data = value
        return data

    def get_consonante(self, word):
        return search_consonant(word)

    def get_year(self, str_date):
        """Get year of birth date."""
        try:
            if str_date is None:
                date = datetime.datetime.today()
            else:
                date = datetime.datetime.strptime(str_date, '%d-%m-%Y').date()
            return date.year
        except Exception as exc:
            raise str(exc)

    def current_year(self):
        return datetime.datetime.now().year
        

class GenerateRFC(BaseGenerator):
    #key_value = 'rfc'
    #DATA_REQUIRED = ('complete_name', 'last_name', 'mother_last_name', 'birth_date')
    partial_data = None
    
    def __init__(self, row): 
        self.complete_name = row[0]           #complete_name
        self.last_name = row[1]                #last_name
        self.mother_last_name = row[2]        #mother_last_name
        self.birth_date = row[3]                #birth_date
        self.parse(complete_name=self.complete_name, last_name=self.last_name, 
                  mother_last_name=self.mother_last_name)
        
        self.partial_data = self.data_fiscal(
            complete_name=self.complete_name, last_name=self.last_name, 
            mother_last_name=self.mother_last_name, birth_date=self.birth_date)
        
    def calculate(self):
        if self.mother_last_name is not None:
            complete_name = u"%s %s %s" % (self.last_name, self.mother_last_name, self.complete_name)
        else:
            complete_name = u"%s %s" % (self.last_name, self.complete_name)
            
        rfc = self.partial_data
        hc = self.homoclave(self.partial_data, complete_name)
        rfc += '%s' % hc
        rfc += self.verification_number(rfc)
        return rfc

    def remove_accents(self, s):
        if type(s) is str:
            s = u"%s" % s
        return ''.join((c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn'))

    def homoclave(self, rfc, complete_name):
        nombre_numero = '0'
        summary = 0 
        div = 0 
        mod = 0

        rfc1 = {
            ' ':00, '&':10, 'Ñ':10, 'A':11, 'B':12, 'C':13, 'D':14, 'E':15, 'F':16,
            'G':17, 'H':18, 'I':19, 'J':21, 'K':22, 'L':23, 'M':24, 'N':25, 'O':26,
            'P':27, 'Q':28, 'R':29, 'S':32, 'T':33, 'U':34, 'V':35, 'W':36, 'X':37,
            'Y':38, 'Z':39, '0':0, '1':1, '2':2, '3':3, '4':4, '5':5, '6':6, '7':7,
            '8':8,'9':9,
        }
        rfc2 = {
            0:'1', 1:'2', 2:'3', 3:'4', 4:'5', 5:'6', 6:'7', 7:'8', 8:'9', 9:'A', 10:'B',
            11:'C', 12:'D', 13:'E', 14:'F', 15:'G', 16:'H', 17:'I', 18:'J', 19:'K',
            20:'L', 21:'M', 22:'N', 23:'P', 24:'Q', 25:'R', 26:'S', 27:'T', 28:'U',
            29:'V', 30:'W', 31:'X', 32:'Y', 33:'Z',
        }

        # Recorrer el nombre y convertir las letras en su valor numérico.
        for count in range(0, len(complete_name)):
            letra = self.remove_accents(complete_name[count])

            nombre_numero += self.rfc_set(str(rfc1[letra]),'00')
        # La formula es:
            # El caracter actual multiplicado por diez mas el valor del caracter
            # siguiente y lo anterior multiplicado por el valor del caracter siguiente.
        for count in range(0,len(nombre_numero)-1):
            count2 = count+1
            summary += ((int(nombre_numero[count])*10) + int(nombre_numero[count2])) * int(nombre_numero[count2])
        
        div = summary % 1000
        mod = div % 34
        div = (div-mod)/34
        homoclave = ''
        homoclave += self.rfc_set(rfc2[int(div)], 'Z')
        homoclave += self.rfc_set(rfc2[int(mod)], 'Z')
        return homoclave

    def verification_number(self, rfc):
        suma_numero = 0 
        suma_parcial = 0
        digito = None 

        rfc3 = {
            'A':10, 'B':11, 'C':12, 'D':13, 'E':14, 'F':15, 'G':16, 'H':17, 'I':18,
            'J':19, 'K':20, 'L':21, 'M':22, 'N':23, 'O':25, 'P':26, 'Q':27, 'R':28,
            'S':29, 'T':30, 'U':31, 'V':32, 'W':33, 'X':34, 'Y':35, 'Z':36, '0':0,
            '1':1, '2':2, '3':3, '4':4, '5':5, '6':6, '7':7, '8':8, '9':9, '':24,
            ' ':37,
        }

        for count in range(0,len(rfc)):
            letra = rfc[count]
            if rfc3[letra]:
                suma_numero = rfc3[letra]
                suma_parcial += (suma_numero*(14-(count+1)))

        modulo = suma_parcial % 11
        digito_parcial = (11-modulo)
        
        if modulo == 0:
            digito = '0'
        if digito_parcial == 10:
            digito = 'A'
        else:
            digito = str(digito_parcial)

        return  digito

    def rfc_set(self, a, b):
        if a == b:
            return b
        else:
            return a

    @property
    def data(self):
        return self.calculate()

# Helper Function para PDF

def convertHtmlToPdf(sourceHtml, outputFilename):
    # open output file for writing (truncated binary)
    resultFile = open(outputFilename, "w+b")

    # convert HTML to PDF
    pisaStatus = pisa.CreatePDF(
            sourceHtml,                # the HTML to convert
            dest=resultFile,
            encoding='utf-8')           # file handle to recieve result

    # close output file
    resultFile.close()                 # close output file

    # return True on success and False on errors
    return pisaStatus.err