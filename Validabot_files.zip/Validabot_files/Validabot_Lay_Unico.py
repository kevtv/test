# -*- coding: utf-8 -*-
"""
Created on Mon Mar  2 09:59:11 2020

@author: d46194
"""

import cx_Oracle
import pandas as pd
import datetime
import os
from base import *
from base import convertHtmlToPdf
from base import GenerateRFC

#os.chdir(r'C:\Users\d46194\Documents\Validabot\App_Siniestros\Validabot version Layout Unico')

df_config = pd.read_excel('config.xlsx')

username = df_config.username.values[0]
password = df_config.password.values[0]
server = df_config.server.values[0]
port = df_config.port.values[0]
sid = df_config.sid.values[0]

con = cx_Oracle.connect(
username,
password,
cx_Oracle.makedsn(
    server,
    port,
    sid))

#user='test'


df = pd.read_excel('layout_unico.xlsx', dtype={'CERTIFICADO':str,'POLIZA':str,'ID_CREDITO':str,'RFC':str,'NUM_OPERACION':str})

df['FECHA_SINIESTRO'] = pd.to_datetime(df['FECHA_SINIESTRO']) # Recomendacion format datetime coerce=ignore
df['YEAR'] = df['FECHA_SINIESTRO'].apply(lambda x: str(x.year))

df['FULL_NAME'] = df['NOMBRE_ASEG'] + ' ' + df['PATERNO_ASEG'] + ' ' + df['MATERNO_ASEG']
df['FULLNAMETRANS'] = df['FULL_NAME'].apply(lambda x: str(x).replace(' ','')) 

lista_nombres = []
for index, row in df.iterrows():
    n_l = []
    n_l.append(row['NOMBRE_ASEG'])
    n_l.append(row['PATERNO_ASEG'])
    n_l.append(row['MATERNO_ASEG'])
    lista_nombres.append(n_l)
    
df['nombre_lista'] = lista_nombres

def limpiar_nombre(nombre_lista):
        nombre_lista_limpio = []
        for nombre in nombre_lista:
            try:
                nombre = nombre.replace(' ','')
                nombre_lista_limpio.append(nombre)
            except Exception as e:
                nombre_lista_limpio.append(nombre_lista)
        return nombre_lista_limpio
    
df['nombre_limpio'] = df['nombre_lista'].apply(lambda x: limpiar_nombre(x))


for index, row in df.iterrows():
    row['nombre_limpio'].append(pd.to_datetime(row['FECHA_NAC']))


rfc_list = []
for index, row in df.iterrows():
    try:
        x = GenerateRFC(row['nombre_limpio']).data
    except Exception as e:
        x = 'NA'
        
    rfc_list.append(x)

df['RFC2'] = rfc_list
    
# =============================================================================
# FUNCIONES
# =============================================================================
def validacion_general(df, user):    
    # Funcion para remover articulos
    
    def remove_article(name):
        "Remove article."
        articles = (
            'DE ', 'DEL ', 'LA ','LOS ', 'LAS ', 'Y ', 'MC ', 'MAC ', 'VON ', 'VAN '
        )
            
        for item in articles:
            name = name.replace(item, '')
        return name
    
    # Funcion para limpiar los espacios en los nombres y hacer el transpuesto
    def limpiar_nombre(nombre_lista):
        nombre_lista_limpio = []
        for nombre in nombre_lista:
            nombre = nombre.replace(' ','')
            nombre_lista_limpio.append(nombre)
        return nombre_lista_limpio
    
    
    
                         
    def html_file(usuario, tiempo, extraccion):
        
        
        html_header =  """
                         <html>
                        <head>
                        <style>
                        
                        @page { /* size and margin of resulting PDF pages */
                        size: A4 landscape;
                        margin: 1cm;
                        }
                        
                        body{
                            font-size: 3px;
                                }
    
                          h2 {
                            text-align: center;
                            font-family: Helvetica, Arial, sans-serif;
                          }
                          table { 
                            margin-left: auto;
                            margin-right: auto;
                            border-collapse: collapse;
                            border-style: hidden;
                            border-left: 0;
                          }
                          table,  td {
                            border: 0px solid black;
                            border-collapse: collapse;
                            border-left: 0;
                          }
                          
                          th{
                            border: 0px solid black;
                            border-collapse: collapse;
                            border-style: hidden;
                            border-left: 0;
                                  }
                          th, td {
                            padding: 5px;
                            text-align: center;
                            font-family: Helvetica, Arial, sans-serif;
                            font-size: 70%;
                            border-left: 0;
                          }
                          table tbody tr:hover {
                            background-color: #dddddd;
                            frame : void;
                            border-left: 0;
                          }
                          .wide {
                            width: 70%; 
                            frame: void;
                            border-left: 0;
                          }
                        </style>
                        </head>
                        <body>
                    
                        <h1>Resultados de la Busqueda</h1>
                        """
        
        
        html_user = """
                    <H2> Usuario: """ + str(usuario) + """</H2>"""
                            
        html_time = """
                    <H2> Hora de consulta: """ + tiempo + """</H2>"""    
        
        html_footer = """
                    </body>
                    </html>
                     """      
                                 
        return html_header + html_user + html_time +  ex_html + html_footer   
    
        
    # =============================================================================
    #     
    # =============================================================================
        
           
        
        
    parent_dir =  os.getcwd()
    directory = 'Validaciones/'
    path = os.path.join(parent_dir, directory)   
    for index, row in df.iterrows():
        try:
            # Query para certificado
            sql_cert = """SELECT PLAN,CARPETA,SOCIO,REMESA,PRODUCTO,PRODUCTO_ACT,POLIZA,POLIZA_FRAUDE,OPERACION,NUM_OPERACION,CERTIFICADO,AP_PATERNO,AP_MATERNO,NOM_ASEG,FECHA_NAC,EDAD_CONT,CAP_INICIAL_FRAUDE,PRIMA_BRUTA_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RFC,RIESGO,SUMA_ASEGURADA,CAP_INICIAL,PRIMA_TOT_FRAUDE,PRIMA_TOTAL_TIT
                            FROM SESA2011.BDU_GLOBAL_UNICA_"""+ row['YEAR'] +"""@LINK_RUBICON
                            WHERE CERTIFICADO = """ + "'"+ str(row['CERTIFICADO']) +"'" + "ORDER BY FECHA_AFECT_INICIO ASC" """"""
            
            extraction = pd.read_sql(sql_cert, con)
            if len(extraction) > 0:  
                ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)
                ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')
                
                today = datetime.datetime.today()
                today_str = today.strftime("%Y%m%d")
                time = today.strftime("%Y-%m-%d, %H:%M:%S ")
                
                file = html_file(user, time, ex_html)
                if pd.isna(row['FULL_NAME']):
                    tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['CERTIFICADO'])+'.html'), 'w',encoding="utf-8")
                    tfile.write(file)
                    tfile.close()
                else:
                    tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                    tfile.write(file)
                    tfile.close()
            
                print('Búsqueda por certificado exitosa!')
      
          
            else:
                try:#
                    # Query para Número de Póliza
                    sql_poliza = """SELECT PLAN,CARPETA,PLAN,SOCIO,REMESA,PRODUCTO,PRODUCTO_ACT,POLIZA,POLIZA_FRAUDE,OPERACION,NUM_OPERACION,CERTIFICADO,AP_PATERNO,AP_MATERNO,NOM_ASEG,FECHA_NAC,EDAD_CONT,CAP_INICIAL_FRAUDE,PRIMA_BRUTA_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RFC,RIESGO,SUMA_ASEGURADA,CAP_INICIAL,PRIMA_TOT_FRAUDE,PRIMA_TOTAL_TIT
                                FROM SESA2011.BDU_GLOBAL_UNICA_"""+ row['YEAR'] +"""@LINK_RUBICON
                                WHERE POLIZA =""" + "'"+ row['POLIZA'] +"'" + """AND NOM_FN_TRANS_2 =""" + "'" + row['FULLNAMETRANS'] + "'" +"ORDER BY FECHA_AFECT_INICIO ASC" """"""
                    
                    extraction = pd.read_sql(sql_poliza, con)
                    if len(extraction) > 0:
                        ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)
                        ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')
                        
                        today = datetime.datetime.today()
                        today_str = today.strftime("%Y%m%d")
                        time = today.strftime("%Y-%m-%d, %H:%M:%S ")
                        
                        file = html_file(user, time, ex_html)
                        if pd.isna(row['FULL_NAME']):
                            tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['POLIZA'])+'.html'), 'w',encoding="utf-8")
                            tfile.write(file)
                            tfile.close()
                        else:
                            tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                            tfile.write(file)
                            tfile.close() 
                        print('Búsqueda por póliza exitosa!!')
                    
                    else:
                        try:#
                            # Query para Número de Operación
                            sql_num_op = """SELECT PLAN,CARPETA,SOCIO,REMESA,PRODUCTO,PRODUCTO_ACT,POLIZA,POLIZA_FRAUDE,OPERACION,NUM_OPERACION,CERTIFICADO,AP_PATERNO,AP_MATERNO,NOM_ASEG,FECHA_NAC,EDAD_CONT,CAP_INICIAL_FRAUDE,PRIMA_BRUTA_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RFC,RIESGO,SUMA_ASEGURADA,CAP_INICIAL,PRIMA_TOT_FRAUDE,PRIMA_TOTAL_TIT
                                            FROM SESA2011.BDU_GLOBAL_UNICA_"""+ row['YEAR'] + """@LINK_RUBICON WHERE NUM_OPERACION ="""+ "'" +row['NUM_OPERACION']+"'" +" ORDER BY FECHA_AFECT_INICIO ASC" """"""
                            
                            extraction = pd.read_sql(sql_num_op, con)
                            if len(extraction) > 0:
                                ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)
                                ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')
                         
                                today = datetime.datetime.today()
                                today_str = today.strftime("%Y%m%d")
                                time = today.strftime("%Y-%m-%d, %H:%M:%S ")
                                
                                if pd.isna(row['FULL_NAME']):
                                        tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['NUM_OPERACION'])+'.html'), 'w',encoding="utf-8")
                                        tfile.write(file)
                                        tfile.close()
                                else:
                                    tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                                    tfile.write(file)
                                    tfile.close()  
                                print('Búsqueda por número de operación exitosa!!')  
                                
                            else:
                                try:#
                                    # Query para ID de Crédito
                                    sql_id_cred = """SELECT CARPETA,PLAN,SOCIO,REMESA,PRODUCTO,POLIZA,POLIZA_FRAUDE,TIPO_POLIZA,CERTIFICADO,NOM_ASEG,AP_PATERNO,AP_MATERNO,RFC, FECHA_NAC,CAP_INICIAL,SUMA_ASEGURADA,CAP_INICIAL_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RIESGO,PRIMA_TOT_FRAUDE,ID_CONCILIACION  
                                                    FROM SESA2011.BDU_GLOBAL_UNICA_"""+ row['YEAR'] +"""@LINK_RUBICON 
                                                    WHERE NUM_OPERACION =""" +"'"+row['ID_CREDITO']+"'" + " ORDER BY FECHA_AFECT_INICIO ASC"
                                                    
                                    extraction = pd.read_sql(sql_id_cred, con) 
                                    if len(extraction) > 0:     
                                
                                        ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)  
                                        ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')                
                                    
                                        today = datetime.datetime.today()
                                        today_str = today.strftime("%Y%m%d")
                                        time = today.strftime("%Y-%m-%d, %H:%M:%S ") 
                                        
                                        if pd.isna(row['ID_CREDITO']):
                                                    tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['ID_CREDITO'])+'.html'), 'w',encoding="utf-8")
                                                    tfile.write(file)
                                                    tfile.close()
                                        else:
                                            tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                                            tfile.write(file)
                                            tfile.close()  
                                        print('Búsqueda por ID de crédito exitosa!!')       
                                    
                                    else:
                                        try:#
                                            # Query para RFC
                                            sql_rfc = """SELECT CARPETA,PLAN,SOCIO,REMESA,PRODUCTO,POLIZA,POLIZA_FRAUDE,TIPO_POLIZA,CERTIFICADO,NOM_ASEG,AP_PATERNO,AP_MATERNO,RFC, FECHA_NAC,CAP_INICIAL,SUMA_ASEGURADA,CAP_INICIAL_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RIESGO,PRIMA_TOT_FRAUDE,ID_CONCILIACION  FROM SESA2011.BDU_GLOBAL_UNICA_"""+row['YEAR']+"""@LINK_RUBICON WHERE RFC="""+"'"+row['RFC2']+"'"+" ORDER BY FECHA_AFECT_INICIO ASC" """"""
                                            
                                            extraction = pd.read_sql(sql_rfc, con)      
                                            
                                            if len(extraction) > 0:     
                                        
                                                ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)  
                                                ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')                
                                            
                                                today = datetime.datetime.today()
                                                today_str = today.strftime("%Y%m%d")
                                                time = today.strftime("%Y-%m-%d, %H:%M:%S ") 
                                                
                                                if pd.isna(row['RFC2']):
                                                            tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['RFC2'])+'.html'), 'w',encoding="utf-8")
                                                            tfile.write(file)
                                                            tfile.close()
                                                else:
                                                    tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                                                    tfile.write(file)
                                                    tfile.close()  
                                                print('Búsqueda por RFC exitosa!!')       
                                            
                                            else: 
                                                try:#
                                                    # Query para Nombre
                                                    sql_name = """SELECT PLAN,CARPETA,SOCIO,REMESA,PRODUCTO,PRODUCTO_ACT,POLIZA,POLIZA_FRAUDE,OPERACION,NUM_OPERACION,CERTIFICADO,AP_PATERNO,AP_MATERNO,NOM_ASEG,FECHA_NAC,EDAD_CONT,CAP_INICIAL_FRAUDE,PRIMA_BRUTA_FRAUDE,FECHA_EMISION_CERT,FECHA_VENC_CERT,DURACION_CERT,FECHA_AFECT_INICIO,FECHA_AFECT_FIN,FECHA_OPERACION,RFC,RIESGO,SUMA_ASEGURADA,CAP_INICIAL,PRIMA_TOT_FRAUDE,PRIMA_TOTAL_TIT,NOM_FN_TRANS_2
                                                                        FROM SESA2011.BDU_GLOBAL_UNICA_"""+ row['YEAR'] +"""@LINK_RUBICON
                                                                        WHERE NOM_FN_TRANS_2=""" +"'"+ row['FULLNAMETRANS'] + "'" """"""
                                                    
                                                    extraction = pd.read_sql(sql_name, con)      
                                                    if len(extraction) > 0:     
                                                    
                                                            ex_html = extraction.to_html(classes='wide', escape=False,border=0,index=False)  
                                                            ex_html = ex_html.replace('<tr style="text-align: right;">', '<tr style="text-align: center; vertical-align: bottom;">')                
                                                        
                                                            today = datetime.datetime.today()
                                                            today_str = today.strftime("%Y%m%d")
                                                            time = today.strftime("%Y-%m-%d, %H:%M:%S ") 
                                                            
                                                            if pd.isna(row['FULL_NAME']):
                                                                        tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                                                                        tfile.write(file)
                                                                        tfile.close()
                                                            else:
                                                                tfile = open(os.path.join(path, str(row['SINIESTRO'])+'_'+str(row['FULL_NAME'])+'.html'), 'w',encoding="utf-8")
                                                                tfile.write(file)
                                                                tfile.close()  
                                                            print('Búsqueda por Nombre exitosa!!')       
                                                        
                                                    else: 
                                                        None 
                                                except Exception as e:
                                                    None         
                                        except Exception as e:
                                            None
                                except Exception as e:
                                    None
                        except Exception as e:
                            None                                            
                except Exception as e:
                    None                                                                                                 
        except Exception as e:
            None
    print('Validacion terminada!!')
        
        
    
    
    
    
                

                 
















