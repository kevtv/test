# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 05:59:01 2020

@author: d46194
"""


import pandas as pd
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import filedialog
from tkinter import ttk
from tkinter import messagebox
from tkinter import *

#Import validaciones por Socio

from Validabot_Lay_Unico import *
#import os

# first file logger
logger = setup_logger('first_logger', 'validator_vig.log')

# second file logger
try:
    super_logger = setup_logger('second_logger', r'S:\BI\logs\validator_logfile.log')
except Exception as e:
    None


##########################
##### MAIN
##########################

print("""
____    ____  ___       __       __   _______       ___       _______   ______   .______          _______   _______ 
\   \  /   / /   \     |  |     |  | |       \     /   \     |       \ /  __  \  |   _  \        |       \ |   ____|
 \   \/   / /  ^  \    |  |     |  | |  .--.  |   /  ^  \    |  .--.  |  |  |  | |  |_)  |       |  .--.  ||  |__   
  \      / /  /_\  \   |  |     |  | |  |  |  |  /  /_\  \   |  |  |  |  |  |  | |      /        |  |  |  ||   __|  
   \    / /  _____  \  |  `----.|  | |  '--'  | /  _____  \  |  '--'  |  `--'  | |  |\  \----.   |  '--'  ||  |____ 
    \__/ /__/     \__\ |_______||__| |_______/ /__/     \__\ |_______/ \______/  | _| `._____|   |_______/ |_______|
                                                                                                                    
____    ____  __    _______  _______ .__   __.   ______  __       ___           _______.                            
\   \  /   / |  |  /  _____||   ____||  \ |  |  /      ||  |     /   \         /       |                            
 \   \/   /  |  | |  |  __  |  |__   |   \|  | |  ,----'|  |    /  ^  \       |   (----`                            
  \      /   |  | |  | |_ | |   __|  |  . `  | |  |     |  |   /  /_\  \       \   \          by Guillermo Izquierdo
   \    /    |  | |  |__| | |  |____ |  |\   | |  `----.|  |  /  _____  \  .----)   |         Coordinador Analytics 
    \__/     |__|  \______| |_______||__| \__|  \______||__| /__/     \__\ |_______/                                
                                                                                                                    
      """)

print("                                                                               BI & ANALYTICS CARDIF MÉXICO")
print("------------------------------------------------------------------------------------------------------------")
print("EJECUCIÓN DEL PROGRAMA EN PROCESO")
logger.info('Ejecucción del programa')
super_logger.info('Ejecucción del programa')

##########################
##### DEFINE DB AND LOAD LAYOUT
##########################



try:
    initial_file = pd.read_excel('layout_unico.xlsx',converters={'CERTIFICADO':str,'POLIZA':str,'ID_CREDITO':str,'RFC':str,'NUM_OPERACION':str})
except:
    print('Coloque el archivo layout_unico.xlsx en la carpeta donde se encuentra el Validabot')
total_registros = len(initial_file)
logger.info("Usuario busco {} registros".format(total_registros))
try:
    super_logger.info("Usuario busco {} registros".format(total_registros))
except Exception as e:
    None

##########################
##### USER INTERFACE
##########################

if __name__ == "__main__":

    
    root = Tk()
#    img2 = PhotoImage(file=resource_path('bi_icon.png'))
#    root.tk.call('wm', 'iconphoto', root._w, img2)
    root.title("VALIDADOR DE VIGENCIAS - CARDIF BI ANALYTICS")
    root.minsize(width=590, height=290)
    root.maxsize(width=590, height=290)
    style = ttk.Style() 
    style.configure('W.TButton', font = ('calibri', 13, 'bold', ), foreground = 'black') 
#    load = Image.open(resource_path("BI_LOGO_300.png"))
#    render = ImageTk.PhotoImage(load)
#    img = Label(root, image=render)
#    img.image = render
#    img.place(x=280, y=-20)
    user = StringVar()
    text = ttk.Label(root, text="Validador de Vigencias para Siniestros", font=("calibri", 11, 'bold'))
    user_t = ttk.Label(root, text="Usuario")
    user_w = ttk.Entry(root,textvariable=user)
    user_w.grid(column=0,row=3, sticky="nsew",pady = 10, padx = 10)
    text_2 = ttk.Label(root, text="Selecciona un Layout:")
    text.grid(column=0,row=1, sticky="nsew",pady = 10, padx = 10)
    user_t.grid(column=0,row=2, sticky="nsw",pady = 10, padx = 10)
    text_2.grid(column=0,row=4, sticky="nsew",pady = 10, padx = 10)
#    combo = ttk.Combobox()
#    combo.set("Layout Único")
#    combo["values"] = ["Layout Único"]
#    combo.grid(column=0,row=5, sticky="nsew",pady = 10, padx = 10)
    pathlabel = Label(root)

   
    ##########################
    ##### BUTTON FUNCTION
    ##########################
    
    def run_bot():
        try:
            usuario = user.get()
            logger.info("Usuario {} inicio validacion".format(usuario))
            try:
                super_logger.info("Usuario {} inicio validacion".format(usuario))
            except Exception as e:
                None
            print("Validación en proceso")
            validacion_general(df, user.get())
        except Exception as e:
            print(e)
            print('No se pudo ejecutar la validación')
        return None
    
    b2 = ttk.Button(root, text='Ejecutar Validación', command=run_bot,style = 'W.TButton')
    b2.grid(column=0, row=7, pady = 10)
    
    text_6 = ttk.Label(root, text="BI & Analytics Transformando Cardif",font=("calibri", 10, 'italic'))
    text_6.grid(column=0,row=9, sticky="sw",pady = 10, padx = 10)
    
    root.mainloop()